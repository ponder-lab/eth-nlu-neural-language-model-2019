# Data Folder Structure

```
data
│   README-DATA.md
│   wordembeddings-dim100.word2vec  
│
└───sentences
│   │   sentences_test.txt
│   │   sentences.continuation
│   │   sentences.eval
|   |   sentences.train
|   └───
└───
```
